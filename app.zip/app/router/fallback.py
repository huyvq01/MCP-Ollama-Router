from typing import Any

from app.models.message import Message
from app.providers.base import BaseProvider


class FallbackManager:
    async def fallback(
        self,
        provider: BaseProvider,
        model: str,
        messages: list[Message],
        **kwargs: Any,
    ) -> str:
        return await provider.chat(
            model=model,
            messages=messages,
            **kwargs,
        )