from app.prompts.builder import builder
from app.providers.registry import ProviderRegistry
from app.registry.service import RegistryService
from app.router.fallback import FallbackManager
from app.router.selector import ModelSelector
from app.services.history import HistoryManager


class RouterEngine:
    def __init__(
        self,
        provider_registry: ProviderRegistry,
        registry: RegistryService,
        history: HistoryManager,
    ) -> None:
        self._provider_registry = provider_registry
        self._registry = registry
        self._history = history

        self.selector = ModelSelector(registry)
        self.fallback = FallbackManager()

    async def chat(
        self,
        session_id: str,
        prompt: str,
    ) -> str:
        provider_name, model = await self.selector.select(prompt)

        provider = self._provider_registry.get(provider_name)

        if provider is None:
            raise RuntimeError(
                f"Provider {provider_name} not found."
            )

        history = self._history.get(session_id)

        messages = builder.build(
            history,
            prompt,
        )

        answer: str = await provider.chat(
            model=model,
            messages=messages,
        )

        self._history.append(
            session_id,
            "user",
            prompt,
        )

        self._history.append(
            session_id,
            "assistant",
            answer,
        )

        return answer

    def clear(
        self,
        session_id: str,
    ) -> None:
        self._history.clear(session_id)

    def sessions(self) -> list[str]:
        return self._history.sessions()