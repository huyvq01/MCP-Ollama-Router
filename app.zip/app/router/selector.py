from app.registry.schemas import ModelMetadata
from app.registry.service import RegistryService
from app.router.matcher import matcher
from app.router.policy import RoutingPolicy


class ModelSelector:
    def __init__(
        self,
        registry: RegistryService,
    ) -> None:
        self._registry = registry
        self.policy = RoutingPolicy()

    async def select(
        self,
        prompt: str,
    ) -> tuple[str, str]:
        capability = matcher.capability(prompt)

        models = self._registry.enabled()

        if not models:
            raise RuntimeError("No available model.")

        ranked: list[ModelMetadata] = sorted(
            models,
            key=lambda m: self.policy.score(
                m,
                capability,
            ),
            reverse=True,
        )

        best = ranked[0]

        return (
            best.provider,
            best.name,
        )