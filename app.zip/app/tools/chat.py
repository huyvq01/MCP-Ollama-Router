from fastmcp import FastMCP

from app.dependencies import container


def register(server: FastMCP):
    @server.tool
    async def chat(
        session_id: str,
        prompt: str,
    ) -> str:
        return await container.router.chat(
            session_id=session_id,
            prompt=prompt,
        )

    @server.tool
    def clear_chat(
        session_id: str,
    ) -> str:
        container.router.clear(session_id)

        return "Conversation cleared."

    @server.tool
    def list_sessions():
        return container.router.sessions()
