from fastmcp import FastMCP

from app.dependencies import container


def register(server: FastMCP):
    @server.tool
    def list_models():
        return container.registry.models()

    @server.tool
    def show_model(
        model: str,
    ):
        return container.registry.model(model)
