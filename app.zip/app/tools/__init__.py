from app.tools.chat import register as register_chat
from app.tools.health import register as register_health
from app.tools.models import register as register_models
from app.tools.system import register as register_system


def register_all(server):
    register_chat(server)

    register_models(server)

    register_health(server)

    register_system(server)
