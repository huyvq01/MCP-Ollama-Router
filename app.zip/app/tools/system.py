from fastmcp import FastMCP

from app.dependencies import container


def register(server: FastMCP):
    @server.tool
    def clear_cache():
        container.cache.clear()

        return "Cache cleared."
