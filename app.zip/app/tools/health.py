from fastmcp import FastMCP

from app.dependencies import container


def register(server: FastMCP):
    @server.tool
    async def health():
        healthy = await container.provider_registry.healthy()

        return {
            "providers": healthy,
            "count": len(healthy),
        }
