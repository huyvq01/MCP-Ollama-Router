from abc import ABC, abstractmethod
from typing import Any

from app.models.message import Message


class BaseProvider(ABC):
    name: str

    @abstractmethod
    async def startup(self) -> None:
        ...

    @abstractmethod
    async def shutdown(self) -> None:
        ...

    @abstractmethod
    async def health(self) -> bool:
        ...

    @abstractmethod
    async def list_models(self) -> list[str]:
        ...

    @abstractmethod
    async def chat(
        self,
        model: str,
        messages: list[Message],
        **kwargs: Any,
    ) -> str:
        ...