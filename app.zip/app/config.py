"""
Global configuration for MCP Ollama Router
"""

from pathlib import Path

# =========================
# Project
# =========================

PROJECT_NAME = "MCP Ollama Router"
PROJECT_VERSION = "1.0.0"

ROOT_DIR = Path(__file__).parent
LOG_DIR = ROOT_DIR / "logs"

# =========================
# Ollama
# =========================

OLLAMA_HOST = "http://127.0.0.1:11434"

OLLAMA_CHAT_API = f"{OLLAMA_HOST}/api/chat"
OLLAMA_TAGS_API = f"{OLLAMA_HOST}/api/tags"
OLLAMA_GENERATE_API = f"{OLLAMA_HOST}/api/generate"

REQUEST_TIMEOUT = 300

# =========================
# Default Model
# =========================

DEFAULT_MODEL = "qwen2.5-coder:7b"

# =========================
# History
# =========================

MAX_HISTORY = 20

# =========================
# Logging
# =========================

LOG_LEVEL = "INFO"
LOG_FILE = LOG_DIR / "router.log"