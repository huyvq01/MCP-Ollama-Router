from app.providers.registry import ProviderRegistry
from app.registry.service import RegistryService
from app.router.engine import RouterEngine
from app.services.cache import Cache
from app.services.history import HistoryManager
from app.services.session import SessionManager


class Container:
    def __init__(self):
        self.provider_registry = ProviderRegistry()

        self.history = HistoryManager()

        self.cache = Cache()

        self.session = SessionManager()

        self.registry = RegistryService(self.provider_registry)

        self.router = RouterEngine(
            provider_registry=self.provider_registry,
            registry=self.registry,
            history=self.history,
        )


container = Container()
