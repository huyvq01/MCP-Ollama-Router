import pytest

from app.dependencies import container
from app.router.selector import ModelSelector


@pytest.mark.asyncio
async def test_selector_select_model():
    provider_registry = container.provider_registry

    await provider_registry.startup()

    try:
        await container.registry.refresh()

        selector = ModelSelector(container.registry)

        provider, model = await selector.select("Write a Python web server.")

        assert isinstance(provider, str)
        assert provider != ""

        assert isinstance(model, str)
        assert model != ""

    finally:
        await provider_registry.shutdown()
