from unittest.mock import AsyncMock

import pytest

from app.registry.service import RegistryService


class FakeProviderRegistry:

    def __init__(self):

        self.provider = AsyncMock()

        self.provider.list_models.return_value = [
            "qwen2.5-coder:7b",
            "deepseek-r1:14b",
        ]

    def get(self, name):

        return self.provider


@pytest.mark.asyncio
async def test_refresh():

    registry = RegistryService(FakeProviderRegistry())

    await registry.refresh()

    models = registry.models()

    assert len(models) == 2

    assert models[0].provider == "ollama"
