from unittest.mock import AsyncMock

import pytest

from app.router.engine import RouterEngine


class FakeProviderRegistry:

    def __init__(self, provider):
        self.provider = provider

    def get(self, name):
        return self.provider


class FakeRegistry:

    pass


class FakeHistory:

    def __init__(self):
        self.data = []

    def get(self, session):
        return []

    def append(self, session, role, content):
        self.data.append((role, content))

    def clear(self, session):
        pass

    def sessions(self):
        return []


@pytest.mark.asyncio
async def test_chat(monkeypatch):

    provider = AsyncMock()
    provider.chat.return_value = "Hello User"

    router = RouterEngine(
        provider_registry=FakeProviderRegistry(provider),
        registry=FakeRegistry(),
        history=FakeHistory(),
    )

    router.selector.select = AsyncMock(
        return_value=(
            "ollama",
            "qwen2.5-coder:7b",
        )
    )

    from app.router import engine

    monkeypatch.setattr(
        engine.builder,
        "build",
        lambda history, prompt: [
            {
                "role": "user",
                "content": prompt,
            }
        ],
    )

    answer = await router.chat(
        "demo",
        "Hello",
    )

    assert answer == "Hello User"

    provider.chat.assert_awaited_once()
