import pytest

from app.registry.schemas import ModelMetadata
from app.router.selector import ModelSelector


class FakeRegistry:

    def enabled(self):
        return [
            ModelMetadata(
                provider="ollama",
                name="coder",
                capabilities=["code"],
                priority=10,
            ),
            ModelMetadata(
                provider="ollama",
                name="general",
                capabilities=["general"],
                priority=50,
            ),
        ]


@pytest.mark.asyncio
async def test_select_code():

    selector = ModelSelector(FakeRegistry())

    provider, model = await selector.select("write python code")

    assert provider == "ollama"
    assert model == "coder"
